# VenegasAI
- Next.js (App Router) + Edge runtime + OpenAI Responses API (streaming)
- Public chat, no auth.

## Dev
cp .env.example .env.local
npm i
npm run dev

## Deploy
- Push to GitHub
- Import on Vercel
- Add `OPENAI_API_KEY` (and optional `OPENAI_MODEL`)
- Assign domain `venegasai.com`