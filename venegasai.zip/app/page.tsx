"use client";
import { useEffect, useRef, useState } from "react";
type Msg = { role: "user" | "assistant"; content: string };

export default function Home() {
  const [messages, setMessages] = useState<Msg[]>([
    { role: "assistant", content: "Hi! I’m VenegasAI. Ask me anything." }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    boxRef.current?.scrollTo({ top: boxRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, loading]);

  async function sendMessage(e: React.FormEvent) {
    e.preventDefault();
    const userMsg: Msg = { role: "user", content: input.trim() };
    if (!userMsg.content) return;
    setInput("");
    setMessages((m) => [...m, userMsg]);
    setLoading(true);
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: messages.concat(userMsg) }),
    });
    if (!res.ok || !res.body) {
      setMessages((m) => [...m, { role: "assistant", content: "Oops—try again." }]);
      setLoading(false);
      return;
    }
    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let assistantText = "";
    setMessages((m) => [...m, { role: "assistant", content: "" }]);
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      const chunk = decoder.decode(value, { stream: true });
      for (const line of chunk.split("\n")) {
        if (line.startsWith("data: ")) {
          const data = line.slice(6).trim();
          if (data === "[DONE]") continue;
          try {
            const json = JSON.parse(data);
            const piece = json.output_text ?? "";
            if (piece) {
              assistantText += piece;
              setMessages((m) => {
                const copy = m.slice();
                copy[copy.length - 1] = { role: "assistant", content: assistantText };
                return copy;
              });
            }
          } catch {}
        }
      }
    }
    setLoading(false);
  }

  return (
    <main className="min-h-screen flex flex-col items-center p-6">
      <div className="w-full max-w-3xl">
        <h1 className="text-2xl font-bold mb-2">VenegasAI</h1>
        <p className="text-sm text-gray-500 mb-4">Simple, fast, public chat.</p>
        <div ref={boxRef} className="border rounded p-4 h-[60vh] overflow-auto bg-white">
          {messages.map((m, i) => (
            <div key={i} className="mb-3">
              <div className="text-xs font-semibold text-gray-500 mb-1">
                {m.role === "user" ? "You" : "VenegasAI"}
              </div>
              <div className="whitespace-pre-wrap">{m.content}</div>
            </div>
          ))}
          {loading && <div className="text-sm text-gray-400">…thinking</div>}
        </div>
        <form onSubmit={sendMessage} className="mt-4 flex gap-2">
          <input
            className="flex-1 border rounded px-3 py-2"
            placeholder="Ask me something…"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
          <button className="border rounded px-4 py-2" disabled={loading}>Send</button>
        </form>
      </div>
    </main>
  );
}