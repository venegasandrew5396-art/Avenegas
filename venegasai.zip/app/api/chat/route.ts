import { openai } from "@/lib/openai";

export const runtime = "edge";

export async function POST(req: Request) {
  const { messages } = await req.json();
  if (!Array.isArray(messages) || messages.length === 0) {
    return new Response("Bad Request", { status: 400 });
  }
  const model = process.env.OPENAI_MODEL || "gpt-4o-mini";
  const response = await openai.responses.stream({
    model,
    input: [
      { role: "system", content: "You are VenegasAI: friendly, concise, and helpful. Answer clearly." },
      ...messages,
    ],
  });
  const stream = response.toReadableStream();
  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      "Connection": "keep-alive",
      "Access-Control-Allow-Origin": "*"
    },
  });
}